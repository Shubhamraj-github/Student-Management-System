<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>Login</title>
  <style media="screen">
    #error_messege {
      color: green;
      font-weight: bold;
    }
     h1{
  color: black;
    text-shadow: 5px 5px 8px  purple;
    font-size:300%;
  }
  img {
  border: 5px solid black;
}
legend {
  background-color: red;
  color: white;
  padding: 5px 10px;
  }
  body {
 background-image: url("../Resources/background.png");
 background-repeat: no-repeat;
 background-size: cover;
}
input[type=text] {
  border: 2px solid red;
  border-radius: 4px;
}
input[type=password] {
  border: 2px solid red;
  border-radius: 4px;
}
table
{
border-color: transparent;
}
a {
  background-color: blueviolet;
  color: white ;
  padding: 1em 1.5em;
  text-decoration: none;
  text-transform: uppercase;
}

  </style>
  <script src="../Script/loginval.js"></script>
</head>

<body>
  <table border="1" cellspacing="0" width="100%">
    <tr>
      <td>
        <table width="100%">
          <tr>
            <td><img height="50px" weight="50px" src="../Resources/logo.png" alt=""></td>
            <td align="center">
              <h1>School Management System</h1>
            </td>
            <td align="right">
              |
              <a href="../../Home/index.html">Back</a>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr>
      <td>
        <table align="center">
          <tr>
            <td>
              <form class="" action="../Controller/logCheck.php" onsubmit="return val()" method="post">
                <fieldset>
                  <legend>LOGIN</legend>
                  <table>
                    <tr>
                      <td>ID</td>
                      <td>: <input type="text" id="id" name="id" value="" placeholder="1002"></td>
                    </tr>
                  </br>
                    <tr>
                      <td>Password</td>
                      <td>: <input type="password" id="password" name="password" value="" placeholder="Youwecan@12"></td>
                    </tr>
                  </table>
                  <br>
                  <input type="submit" name="submit" value="LOGIN" >
                </fieldset>
              </form>
            </td>
          </tr>
          <tr>
            <td colspan="2">
              <center>
                <div id="error_messege">
                </div>
              </center>
            </td>
          </tr>

        </table>
      </td>
    </tr>
    <tr>
      <td align="center"><b>Copyright Ⓒ 2022</b></td>
    </tr>
  </table>
</body>

</html>