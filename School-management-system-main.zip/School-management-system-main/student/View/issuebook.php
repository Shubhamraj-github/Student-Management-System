<?php
$title= "Issue Book History";
include('header.php');
include_once('../model/DatabaseConnection.php');
$viewhistory = getissuedbook($_COOKIE['id']);
?>

<?php include('sideBar.php'); ?> 
<td>
            <fieldset>
                <legend><b>Issue Book History</b></legend>
            <form class="" action="" method="post"> 
               <table>

               <tr>
                <td><b>ID</b></td> 
                <td>:</td>
                <td><?php echo $viewhistory['id']; ?></td>
               </tr>

               <tr>
                <td><b>Book Name</b></td> 
                <td>:</td>
                <td><?php echo $viewhistory['title']; ?></td>
               </tr>

               <tr>
                <td><b>Issue Date</b></td> 
                <td>:</td>
                <td><?php echo $viewhistory['issuesdate']; ?></td>
               </tr>
               <tr>
                <td><b>Return Date</b></td> 
                <td>:</td>
                <td><?php echo $viewhistory['returndate']; ?></td>
               </tr>
               <tr>
                <td><b>Fine</b></td> 
                <td>:</td>
                <td><?php echo $viewhistory['fine']; ?></td>
               </tr>

               </table>
               
            </form>
            </fieldset>
        </td>
      </tr>

      <?php include('footer.php'); ?>