<?php
$title= "View Profile";
include('header.php');
include_once('../model/DatabaseConnection.php');
$viemyinfo = getUserbyid($_COOKIE['id']);
?>

<?php include('sideBar.php'); ?> 
        <td>
            <fieldset>
                <legend><b>MY PROFILE</b></legend>
            <form class="" action="" method="post"> 
               <table>
               <tr>
                <td><b>Name</b></td>
                <td>:</td>
                <td><?php echo $viemyinfo['name']; ?></td>
               </tr>

               <tr>
                <td><b>Email</b></td> 
                <td>:</td>
                <td><?php echo $viemyinfo['email']; ?></td>
               </tr>

               <tr>
                <td><b>Mobile No</b></td> 
                <td>:</td>
                <td><?php echo $viemyinfo['mobile']; ?></td>
               </tr>
              
               <tr>
                <td><b>Student Id</b></td> 
                <td>:</td>
                <td> <?php echo $viemyinfo['id']; ?></td>
               </tr>

               <tr>
                <td><b>Gender</b></td> 
                <td>:</td>
                <td><?php echo $viemyinfo['gender']; ?></td>
               </tr>


               <tr>
                <td><b>Date of Birth</b></td> 
                <td>:</td>
                <td><?php echo $viemyinfo['dob']; ?></td>
               </tr>

               <tr>
                <td><b>Present Address</b></td> 
                <td>:</td>
                <td><?php echo $viemyinfo['p_address']; ?></td>
               </tr>

               <tr>
                <td><b>Class</b></td> 
                <td>:</td>
                <td><?php echo $viemyinfo['class']; ?></td>
               </tr>

               
               
               <tr>
                <td><b>Section</b></td> 
                <td>:</td>
                <td><?php echo $viemyinfo['section']; ?></td>
               </tr>

            
               <tr>
                <td><b>Roll No</b></td> 
                <td>:</td>
                <td><?php echo $viemyinfo['roll']; ?></td>
               </tr>

               
               
               </table>
               
            </form>
            </fieldset>
            <a href="edit.php"><b>Edit</b></a>
        </td>
      </tr>
      <?php include('footer.php'); ?>