<?php
$title= "View Leave Request";
include('header.php');
include_once('../model/DatabaseConnection.php');
$viewmyleave = getleavebyid($_COOKIE['id']);
?>

<?php include('sideBar.php'); ?> 
        <td>
            <fieldset>
                <legend><b>View Leave Request</b></legend>
            <form class="" action="" method="post"> 
               <table>


               <tr>
                <td><b>Name<b></td> 
                <td>:</td>
                <td><?php echo $viewmyleave['name']; ?></td>
               </tr>

               <tr>
                <td><b>ID</b></td> 
                <td>:</td>
                <td><?php echo $viewmyleave['id']; ?></td>
               </tr>

               <tr>
                <td><b>Leave From</b></td> 
                <td>:</td>
                <td><?php echo $viewmyleave['leave_from']; ?></td>
               </tr>

               <tr>
                <td><b>Leave To</b></td> 
                <td>:</td>
                <td><?php echo $viewmyleave['leave_to']; ?></td>
               </tr>

               
               <tr>
                <td><b>Status</b></td> 
                <td>:</td>
                <td><?php echo $viewmyleave['action']; ?></td>
               </tr>

               </table>
               
            </form>
            </fieldset>
        </td>
      </tr>

      <?php include('footer.php'); ?>