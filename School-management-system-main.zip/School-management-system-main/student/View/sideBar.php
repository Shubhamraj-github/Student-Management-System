<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title></title>
  <style type="text/css">
    h1{
  color: black;
    text-shadow: 5px 5px 8px  purple;
    font-size:300%;
    text-align: center;
  }
  img {
  border: 5px solid black;
}

table{
  border-style: solid;
  border-color: transparent;
}
legend {
  background-color: red;
  color: white;
  padding: 5px 10px;
}
fieldset{
border-color: black;
}
 img:hover {
  
  animation: shake 0.5s;

  
  animation-iteration-count: infinite;
}

@keyframes shake {
  0% { transform: translate(1px, 1px) rotate(0deg); }
  10% { transform: translate(-1px, -2px) rotate(-1deg); }
  20% { transform: translate(-3px, 0px) rotate(1deg); }
  30% { transform: translate(3px, 2px) rotate(0deg); }
  40% { transform: translate(1px, -1px) rotate(1deg); }
  50% { transform: translate(-1px, 2px) rotate(-1deg); }
  60% { transform: translate(-3px, 1px) rotate(0deg); }
  70% { transform: translate(3px, 1px) rotate(-1deg); }
  80% { transform: translate(-1px, -1px) rotate(1deg); }
  90% { transform: translate(1px, 2px) rotate(0deg); }
  100% { transform: translate(1px, -2px) rotate(-1deg); }
}
body {
 background-image: url("../Resources/background1.jpg");
 background-repeat: no-repeat;
 background-size: cover;
}
a{
  color: black;
}

}
#navigation h2{
    font-size: 25px;
    text-align: center;
}
#navigation h2 a{
    text-decoration: none;
    color: #000;
}
#navigation h2 a:hover{
    color: blue;
}
#navigation p{
    color: red;
    font-size: 20px;
}
#sidebar ul li{
    list-style-type: none;
    font-size: 20px;
    padding: 5px 2px;
}
#navigation{

}
#sidebar ul li:last-child{
    border-bottom: 0;
}
#sidebar ul li a{
    text-decoration: none;
    color: #000;
}
#sidebar ul li a:hover{
    color: blue;
}
#header{
  color: #1a075e;

}
#header a{
  color: #000;
  text-decoration: none;
  font-size: 20px;
  margin-right: 10px;
  margin-left: inherit;

}
#header  a:hover{
    color: red;
}
.tab {
  padding-left: 8px;
}

 #section{
  padding: 8px 83px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}
#classE{
 padding: 8px 69px;
 margin: 8px 0;
 display: inline-block;
 border: 1px solid #ccc;
 box-sizing: border-box;
}

#description{
  padding: 8px 19px;
  margin: 8px 0;
  margin-left: 5px;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

#box a{
  font-size: 20px;
  text-decoration: none;
  color: #000;


}
#box a:hover{
    color: blue;
}
input[type=button]{
  background-color: #22A7F0;
  width: auto;
  color: black;
  padding: 5px 10px;
  cursor: pointer;
}
input[type=button]:hover{
  opacity: 0.8;
}
input[type=submit]{
  background-color: #4CAF50;
  width: auto;
  color: white;
  padding: 5px 10px;
  cursor: pointer;
  /* width: 100%; */
}
input[type=submit]:hover {
  opacity: 0.8;
}
  </style>
</head>
<body>



<tr>
        <td width="250px">
          <h3>My Account</h3>
          <hr>
          <div id="sidebar">
          <ul>
            <li><a href="dashboard.php"><b>Dashboard</b></a></li>  
            <li><a href="viewprofile.php"><b>View Profile</b></a></li>
            <li><a href="teachernotice.php"><b>Teachers Notice</b></a></li>
            <li><a href="teacherprofile.php"><b>Teachers Contact Details</b></a></li>
            <li><a href="schoolnotice.php"><b>School Notices</b></a></li>
            <li><a href="result.php"><b>Own Result</b></a></li>
            <li><a href="reset.php"><b>Change Password</b></a></li>
            <li><a href="leaverequest.php"><b>Request for leave</b></a></li>
            <li><a href="coursedetails.php"><b>Course Details</b></a></li>
            <li><a href="issuebook.php"><b>Issue Book History</b></a></li>
            <li><a href="booksinfo.php"><b>Information of Books</b></a></li>

          </ul>
        </div>
        </td>

        </body>
</html>