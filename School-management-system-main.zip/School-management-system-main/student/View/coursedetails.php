<?php
$title= "Course Details";
$javascript = "../Script/courseSearch.js";
require_once('../Model/DatabaseConnection.php');
$courseList=getAllcourse();
include('header.php');
?>
 
<?php include('sideBar.php'); ?> 
        <td>
            <center><h2><u>Course Details</u></h2></center>
            <center>
                  <b>Find Course Info:</b><input type="text" onkeyup="ajax()" name="name" id="name" placeholder="Enter Course Name">
                  <input type="button" name="" value="Find">
                </center>
          <div id="myh1" class="">
                  <br>
            <?php
                echo "<table border = 1 width='100%' cellspacing = 0  >
                <tr align = 'center'>
                    <td><b>ID</b></td>
                    <td><b>Course Name</b></td>
                    <td><b>Class</b></td>
                    <td><b>Description</b></td>
                </tr>";
                for($i = 0; $i<count($courseList); $i++){
                    echo "<tr align = 'center'>
                    <td>{$courseList[$i]['id']}</td>
                    <td>{$courseList[$i]['course_name']}</td>
                    <td>{$courseList[$i]['class']}</td>
                    <td>{$courseList[$i]['description']}</td>
                </tr>";
                }
                echo "</table>";
                ?>
                </div>
        </td>
      </tr>

      <?php include('footer.php'); ?>