<?php
$title= "Dashboard";
include('header.php');
?>

<?php include('sideBar.php'); ?> 
        <td>
          <h1>Welcome to student page</h1>
        </td>
      </tr>

    <?php include('footer.php'); ?>