<?php

	header('location: Home/index.html');

?>
