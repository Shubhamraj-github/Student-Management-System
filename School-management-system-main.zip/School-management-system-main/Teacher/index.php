<?php



header('location: View/LoginPage.php');



?>