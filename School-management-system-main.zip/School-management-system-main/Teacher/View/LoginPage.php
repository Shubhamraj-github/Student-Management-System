<!DOCTYPE html>
<html>
  <head>
    <title>Public Home</title>
    <style media="screen">
      #error_messege{
        color: blue;
        font-weight: bold;
      }
      h1{
  color: black;
    text-shadow: 5px 5px 8px  purple;
    font-size:300%;
    </style>
    <script src="../Script/LogCheck(script).js"></script>
  </head>
  <body>
    <table border="1" cellspacing="0" width="100%" >
      <tr>
        <td>
            <table width="100%">
                <tr>
                  <td><img height="40px" weight="40px" src="../Resources/school_logo.png" alt=""></td>
                  <td align = "center"><h1>School Management System</h1></td>
                  <td align = "right">
                      
                      <a href="../../Home/index.html">Back</a>
                  </td>
                </tr>
            </table>
          </td>
      </tr>
      <tr>
        <td height="150px" weight="150px" colspan="2">
            <!DOCTYPE html>
<html>
    <head>
        <title>HTML Site</title>
        <style type="text/css">
            img {
  border: 5px solid black;
}
a {
  background-color: blueviolet;
  color: white ;
  padding: 1em 1.5em;
  text-decoration: none;
  text-transform: uppercase;
}
legend {
  background-color: red;
  color: white;
  padding: 5px 10px;
}
body {
 background-image: url("../Resources/background.png");
 background-repeat: no-repeat;
 background-size: cover;
}
input[type=text] {
  border: 2px solid red;
  border-radius: 4px;
}
input[type=password] {
  border: 2px solid red;
  border-radius: 4px;
}
table
{
border-color: transparent;
}



        </style>
    </head>
    <body>
         <table align="center">
             <tr>
                <td></td>
                <td>
                    <form method="post" id="LoginForm" action="../Controller/LogCheck.php" onsubmit="return LoginValid()"> 
                        <fieldset width="5px">
                            <legend>LOGIN</legend>
        <form class="" action="" method="post">
           <table>
           <tr>
            <td>ID:</td> 
            <td><input type="text" id="id" name="ID" value="" placeholder="1001"></td>
           </tr>
       </br>
           <tr>
            <td>Password:</td> 
            <td><input type="password" id="password" name="password" value="" placeholder="Youwecan@12"></td>
           </tr>
           </table>
            <br>
                    <input type="submit" id="submit" name="submit" value="LOGIN">
                    <br> 
            <center>
              <div id="error_messege">
              </div>
            </center>
        </form>
                        </fieldset>
                        </form>
                </td>
                <td></td>
             </tr>
         </table>
    </body>
</html>
        </td>
      </tr>
      
      <?php include("TeacherFooter.php") ?>
    </table>

  </body>
</html>