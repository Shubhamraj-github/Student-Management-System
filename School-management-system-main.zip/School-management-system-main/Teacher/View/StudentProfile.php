<?php
	session_start();
  require_once('../Model/DatabaseConnection.php');
  $Id = $_GET['id'];
	$User =  getStudentById($Id);
  $_SESSION['id'] = $Id;
	if(isset($_COOKIE['flag']))
	{
?>


<!DOCTYPE html>
<html>
  <head>
    <title>Public Home</title>
    <style type="text/css">
        h1{
  color: black;
    text-shadow: 5px 5px 8px  purple;
    font-size:300%;
    text-align: center;
  }
  img {
  border: 5px solid black;
}

table{
  border-style: solid;
  border-color: transparent;
}
legend {
  background-color: red;
  color: white;
  padding: 5px 10px;
}
fieldset{
border-color: black;
}
 img:hover {
  
  animation: shake 0.5s;

  
  animation-iteration-count: infinite;
}

@keyframes shake {
  0% { transform: translate(1px, 1px) rotate(0deg); }
  10% { transform: translate(-1px, -2px) rotate(-1deg); }
  20% { transform: translate(-3px, 0px) rotate(1deg); }
  30% { transform: translate(3px, 2px) rotate(0deg); }
  40% { transform: translate(1px, -1px) rotate(1deg); }
  50% { transform: translate(-1px, 2px) rotate(-1deg); }
  60% { transform: translate(-3px, 1px) rotate(0deg); }
  70% { transform: translate(3px, 1px) rotate(-1deg); }
  80% { transform: translate(-1px, -1px) rotate(1deg); }
  90% { transform: translate(1px, 2px) rotate(0deg); }
  100% { transform: translate(1px, -2px) rotate(-1deg); }
}
body {
 background-image: url("../Resources/background1.jpg");
 background-repeat: no-repeat;
 background-size: cover;
}
a{
  color: black;
}

}
#navigation h2{
    font-size: 25px;
    text-align: center;
}
#navigation h2 a{
    text-decoration: none;
    color: #000;
}
#navigation h2 a:hover{
    color: blue;
}
#navigation p{
    color: red;
    font-size: 20px;
}
#sidebar ul li{
    list-style-type: none;
    font-size: 20px;
    padding: 5px 2px;
}
#navigation{

}
#sidebar ul li:last-child{
    border-bottom: 0;
}
#sidebar ul li a{
    text-decoration: none;
    color: #000;
}
#sidebar ul li a:hover{
    color: blue;
}
#header{
  color: #1a075e;

}
#header a{
  color: #000;
  text-decoration: none;
  font-size: 20px;
  margin-right: 10px;
  margin-left: inherit;

}
#header  a:hover{
    color: red;
}
.tab {
  padding-left: 8px;
}

 #section{
  padding: 8px 83px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}
#classE{
 padding: 8px 69px;
 margin: 8px 0;
 display: inline-block;
 border: 1px solid #ccc;
 box-sizing: border-box;
}

#description{
  padding: 8px 19px;
  margin: 8px 0;
  margin-left: 5px;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

#box a{
  font-size: 20px;
  text-decoration: none;
  color: #000;


}
#box a:hover{
    color: blue;
}

    </style>
  </head>
  <body>
    <table border="1" cellspacing="0" width="100%" >
    <?php include("TeacherHeader.php") ?>
      <tr>
        <tr>
            <td align="Left"><img height="80px" weight="80px" src="../Resources/Student.jpg" alt=""></td>
            <td align="Center">
            <h1>
              Student's Profile Information
            </h1>
            </td>
          </tr>
        <td height="150px" weight="150px">
            <div id="sidebar">
                <ul>
                    <li><a href="TeacherDashboard.php"><b>Dashboard</b></a></li>
                    <li><a href="ViewProfile.php"><b>View Profile</b></a></li>
                    <li><a href="StudentList.php"><b>View Student's Profile</b></a></li>
                    <li><a href="Schedule.php"><b>Class Schedule</b></a></li>
                    <li><a href="NoticeBoard.php"><b>Notice Board</b></a></li>
                    <li><a href="ViewSchoolNotice.php"><b>School Notice</b></a></li>
                    <li><a href="StudentListMarks.php"><b>Student Marks</b></a></li>
                    <li><a href="LeaveRequest.php"><b>Student Leave Request</b></a></li>
                    <li><a href="BookHistory.php"><b>Book History</b></a></li>
                    <li><a href="ChangePass.php"><b>Reset Password</b></a></li>
                    <li><a href="../Controller/Logout.php"><b>Logout</b></a></li>
                </ul>
            </div>
        </td>
        <td>
            <fieldset>
                <legend><b>STUDENT PROFILE</b></legend>
            <form class="" action="" method="post">
            <table>
               <tr>
                <td><b>Name</b></td>
                <td>:<?php echo $User['name'];?></td>
               </tr>
               <tr>
                <td><b>Email</b></td> 
                <td>:<?php echo $User['email'];?></td>
               </tr>
               <tr>
                <td><b>Mobile No.</b></td> 
                <td>:<?php echo $User['mobile'];?></td>
               </tr>
               <tr>
                <td><b>ID</b></td> 
                <td>:<?php echo $User['id'];?></td>
               </tr>
               <tr>
                <td><b>Gender</b></td> 
                <td>:<?php echo $User['gender'];?></td>
               </tr>
               <tr>
                <td><b>Date of Birth</b></td> 
                <td>:<?php echo $User['dob'];?></td>
               </tr>
               <tr>
                <td><b>Present Address</b></td> 
                <td>:<?php echo $User['p_address'];?></td>
               </tr>
               <tr>
                <td><b>Class</b></td> 
                <td>:<?php echo $User['class'];?></td>
               </tr>
               <tr>
                <td><b>Section</b></td> 
                <td>:<?php echo $User['section'];?></td>
               </tr>
               <tr>
                <td><b>Roll</b></td> 
                <td>:<?php echo $User['roll'];?></td>
               </tr>
               </table>
            </form>
            </fieldset>
        </td>
      </tr>
      <?php include("TeacherFooter.php") ?>
    </table>

  </body>
</html>


<?php

	}else{
		header('location: LoginPage.php');
	}

?>
