<?php
	session_start();
  require_once('../Model/DatabaseConnection.php');
	$GetNotice = getAllNotice();
	if(isset($_COOKIE['flag']))
	{
?>


<!DOCTYPE html>
<html>
  <head>
    <title>Public Home</title>
    <style type="text/css">
      
       h1{
  color: black;
    text-shadow: 5px 5px 8px  purple;
    font-size:300%;
    text-align: center;
  }
       a{
            color: black;
        }
        table{
  border-style: solid;
  border-color: transparent;
}
legend {
  background-color: red;
  color: white;
  padding: 5px 10px;
}
fieldset{
border-color: black;

}
img {
  border: 5px solid black;
}
img:hover {
  
  animation: shake 0.5s;

  
  animation-iteration-count: infinite;
}

@keyframes shake {
  0% { transform: translate(1px, 1px) rotate(0deg); }
  10% { transform: translate(-1px, -2px) rotate(-1deg); }
  20% { transform: translate(-3px, 0px) rotate(1deg); }
  30% { transform: translate(3px, 2px) rotate(0deg); }
  40% { transform: translate(1px, -1px) rotate(1deg); }
  50% { transform: translate(-1px, 2px) rotate(-1deg); }
  60% { transform: translate(-3px, 1px) rotate(0deg); }
  70% { transform: translate(3px, 1px) rotate(-1deg); }
  80% { transform: translate(-1px, -1px) rotate(1deg); }
  90% { transform: translate(1px, 2px) rotate(0deg); }
  100% { transform: translate(1px, -2px) rotate(-1deg); }
}
body {
 background-image: url("../Resources/background1.jpg");
 background-repeat: no-repeat;
 background-size: cover;
}

#navigation h2{
    font-size: 25px;
    text-align: center;
}
#navigation h2 a{
    text-decoration: none;
    color: #000;
}
#navigation h2 a:hover{
    color: blue;
}
#navigation p{
    color: red;
    font-size: 20px;
}
#sidebar ul li{
    list-style-type: none;
    font-size: 20px;
    padding: 5px 2px;
}
#navigation{

}
#sidebar ul li:last-child{
    border-bottom: 0;
}
#sidebar ul li a{
    text-decoration: none;
    color: #000;
}
#sidebar ul li a:hover{
    color: blue;
}
#header{
  color: #1a075e;

}
#header a{
  color: #000;
  text-decoration: none;
  font-size: 20px;
  margin-right: 10px;
  margin-left: inherit;

}
#header  a:hover{
    color: red;
}
.tab {
  padding-left: 8px;
}


 #section{
  padding: 8px 83px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}
#classE{
 padding: 8px 69px;
 margin: 8px 0;
 display: inline-block;
 border: 1px solid #ccc;
 box-sizing: border-box;
}

#description{
  padding: 8px 19px;
  margin: 8px 0;
  margin-left: 5px;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

#box a{
  font-size: 20px;
  text-decoration: none;
  color: #000;


}
#box a:hover{
    color: blue;
}


    </style>
  </head>
  <body>
    <table border="1" cellspacing="0" width="100%" >
    <?php include("TeacherHeader.php") ?>
      <tr>
        <tr>
            <td align="Left"><img height="80px" weight="80px" src="../Resources/notice.jpg" alt=""></td>
            <td align="Center">
            <h1>
              Notice View
            </h1>
            </td>
          </tr>
        <td height="150px" weight="150px">
                <div id="sidebar">
                <ul>
                    <li><a href="TeacherDashboard.php"><b>Dashboard</b></a></li>
                    <li><a href="ViewProfile.php"><b>View Profile</b></a></li>
                    <li><a href="StudentList.php"><b>View Student's Profile</b></a></li>
                    <li><a href="Schedule.php"><b>Class Schedule</b></a></li>
                    <li><a href="NoticeBoard.php"><b>Notice Board</b></a></li>
                    <li><a href="ViewSchoolNotice.php"><b>School Notice</b></a></li>
                    <li><a href="StudentListMarks.php"><b>Student Marks</b></a></li>
                    <li><a href="LeaveRequest.php"><b>Student Leave Request</b></a></li>
                    <li><a href="BookHistory.php"><b>Book History</b></a></li>
                    <li><a href="ChangePass.php"><b>Reset Password</b></a></li>
                    <li><a href="../Controller/Logout.php"><b>Logout</b></a></li>
                </ul>
              </div>
        </td>
        <td>
            <fieldset>
                <legend><b>NOTICES</b></legend>
            <form class="" action="" method="post">
            <?php
								echo "<table border = 1 width='100%' cellspacing = 0  >
								<tr align = 'center'>
								    <td><b>ID</b></td>
								    <td><b>Notice</b></td>
								    <td><b>Time</b></td>
                    <td><b>Action</b></td>
								</tr>";
								for($i = 0; $i<count($GetNotice); $i++){
								    echo "<tr align = 'center'>
								    <td>{$GetNotice[$i]['id']}</td>
								    <td>{$GetNotice[$i]['notice']}</td>
								    <td>{$GetNotice[$i]['time']}</td>
                    <td> <a href='EditNotice.php?id={$GetNotice[$i]['id']}'> Edit </a> | <a href='DeleteNotice.php?id={$GetNotice[$i]['id']}'> Delete </a>  </td>
								</tr>";
								}
								echo "</table>";
								?>
            </form>
            </fieldset>
        </td>
      </tr>
      <?php include("TeacherFooter.php") ?>
    </table>

  </body>
</html>


<?php

	}else{
		header('location: LoginPage.php');
	}

?>
