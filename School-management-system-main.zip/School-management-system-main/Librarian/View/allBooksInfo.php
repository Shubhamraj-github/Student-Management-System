<?php 
$title= "View All Book";
include_once('../Model/usersmodel.php');
include('header.php');
$booksinfo = getAllBooksInfo();
?>
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <style type="text/css">
      input[type=button]{
  background-color: #22A7F0;
  width: auto;
  color: black;
  padding: 5px 10px;
  cursor: pointer;
}
input[type=button]:hover{
  opacity: 0.8;
}
      
    </style>
  </head>
  <body>
  
  
    <table border="1" cellspacing="0" width="100%" >
      <tr>
        <td colspan="2">
          <table width="100%">
            <tr>
              <td><img height="50px" weight="50px" src="../Resources/logo.png" alt=""></td>
              <td align = "center"><h1>School Management System</h1></td>
              <td align = "right">
                <a href="../Controller/logout.php"><b>Logout</b></a>
              </td>
            </tr>
          </table>
        </td>
      </tr>
 
      <tr id="navigation">
        <td width="350px">
        <h2 align="center"><a href="viewLibrarianProfile.php">My Profile</a></h2></h2>
          <h3 align="center"><a href="dashboard.php">Go to Dashboard</a></h3></br>
          <div id="sidebar">
          <ul>
            <li><a href="addnewbook.php"><b>Add New Book</b></a></li>
            <li><a href="allBooksInfo.php"><b>All Book Information</b></a></li>
            <li><a href="viewStudentsList.php"><b>View Students List</b></a></li>
            <li><a href="viewTeachersList.php"><b>View Teachers List</b></a></li>
            <li><a href="studentLibraryAcc.php"><b>Create Student Library Account</b></a></li>
            <li><a href="viewAllStudentsLibProfile.php"><b>View Student Library Account</b></a></li>
            <li><a href="issueNewBook.php"><b>Add Issue Book</b></a></li>
            <li><a href="issuedBookHistory.php"><b>Issue Book History</b></a></li>
            
          </ul>
          </div>
        </td>
        <td id="main content"><h2 align="center" ><?php echo $title; ?></h2><hr>
                    
<script type="text/javascript" src="../js/booksearch.js"></script>
<input type="text" name="title" id="title" placeholder="Enter Book Title" onkeyup="ajax()" />
	<input type="button" name="" value="Search">
    <br>
    <div id="myh1" class="">
      <div id="notice">
    <table border="1">
        <tr align="center">
            <th>Serial No.</th>
            <th>ISBN</th>
            <th>Book Title</th>
            <th>Author</th>
            <th>Edition</th>
            <th>Categories</th>
            <th>Book Item No.</th>
            <th>Action</th>
        </tr>
        <?php  for($i=0; $i < count($booksinfo); $i++){ ?>
         <tr align="center">
             <td><?php echo $booksinfo[$i]['sl'] ?></td>
             <td><?php echo $booksinfo[$i]['isbn'] ?></td>
             <td><?php echo $booksinfo[$i]['title'] ?></td>
             <td><?php echo $booksinfo[$i]['author'] ?></td>
             <td><?php echo $booksinfo[$i]['edition'] ?></td>
             <td><?php echo $booksinfo[$i]['categories'] ?></td>
             <td><?php echo $booksinfo[$i]['bookcopy'] ?></td>
             <td>
                  
                  <a href="editBookInfo.php?serialno=<?php echo $booksinfo[$i]['sl']; ?>"><b>UPDATE</b></a> 
                  <a href="deleteBookInfo.php?serialno=<?php echo $booksinfo[$i]['sl']; ?>"><b>DELETE</b></a>
             </td>
         </tr><?php  } ?></div>
             </table>
            </div>
         </div>
         </body>
  </html>

      <?php include('footer.php'); ?>   
 