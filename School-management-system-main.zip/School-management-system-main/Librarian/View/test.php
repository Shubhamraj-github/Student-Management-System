<?php  
// $user = ["kader",21,"dhaka"];
// if(count($user) > 2){
//     echo $user['2'];
// }else{
//     echo "wrong";
// }

// $a = time()- 86400;
// echo $a;

?>