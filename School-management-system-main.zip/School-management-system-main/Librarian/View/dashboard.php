<?php $title= "Dashboard";
include_once('../Model/usersmodel.php');
$allnotices = viewAllNotice();
	include('header.php');
   ?>
   <!DOCTYPE html>
   <html>
   <head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <title></title>
     <style type="text/css">
        h1{
  color: black;
    text-shadow: 5px 5px 8px  purple;
    font-size:300%;
    text-align: center;
  }
       a{
            color: black;
        }
        table{
  border-style: solid;
  border-color: transparent;
}
legend {
  background-color: red;
  color: white;
  padding: 5px 10px;
}
fieldset{
border-color: black;

}
img {
  border: 5px solid black;
}
img:hover {
  
  animation: shake 0.5s;

  
  animation-iteration-count: infinite;
}

@keyframes shake {
  0% { transform: translate(1px, 1px) rotate(0deg); }
  10% { transform: translate(-1px, -2px) rotate(-1deg); }
  20% { transform: translate(-3px, 0px) rotate(1deg); }
  30% { transform: translate(3px, 2px) rotate(0deg); }
  40% { transform: translate(1px, -1px) rotate(1deg); }
  50% { transform: translate(-1px, 2px) rotate(-1deg); }
  60% { transform: translate(-3px, 1px) rotate(0deg); }
  70% { transform: translate(3px, 1px) rotate(-1deg); }
  80% { transform: translate(-1px, -1px) rotate(1deg); }
  90% { transform: translate(1px, 2px) rotate(0deg); }
  100% { transform: translate(1px, -2px) rotate(-1deg); }
}
body {
 background-image: url("../Resources/background1.jpg");
 background-repeat: no-repeat;
 background-size: cover;
}

#navigation h2{
    font-size: 25px;
    text-align: center;
}
#navigation h2 a{
    text-decoration: none;
    color: #000;
}
#navigation h2 a:hover{
    color: blue;
}
#navigation p{
    color: red;
    font-size: 20px;
}
#sidebar ul li{
    list-style-type: none;
    font-size: 20px;
    padding: 5px 2px;
}
#navigation{

}
#sidebar ul li:last-child{
    border-bottom: 0;
}
#sidebar ul li a{
    text-decoration: none;
    color: #000;
}
#sidebar ul li a:hover{
    color: blue;
}
#header{
  color: #1a075e;

}
#header a{
  color: #000;
  text-decoration: none;
  font-size: 20px;
  margin-right: 10px;
  margin-left: inherit;

}
#header  a:hover{
    color: red;
}
.tab {
  padding-left: 8px;
}


 #section{
  padding: 8px 83px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}
#classE{
 padding: 8px 69px;
 margin: 8px 0;
 display: inline-block;
 border: 1px solid #ccc;
 box-sizing: border-box;
}

#description{
  padding: 8px 19px;
  margin: 8px 0;
  margin-left: 5px;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

#box a{
  font-size: 20px;
  text-decoration: none;
  color: #000;


}
#box a:hover{
    color: blue;
}

     </style>
   </head>
   <body>
   
   
    <table border="1" cellspacing="0" width="100%" >
      <tr>
        <td colspan="2">
          <table width="100%">
            <tr>
              <td><img height="50px" weight="50px" src="../Resources/logo.png" alt=""></td>
              <td align = "center"><h1>School Management System</h1></td>
              <td align = "right" >
                <a id="logout" href="../Controller/logout.php"><b>Logout<b></a>
              </td>
            </tr>
          </table>
        </td>
      </tr>
 
      <tr id="navigation">
        <td width="350px">
          <h2 align="center"><a href="viewLibrarianProfile.php">My Profile</a></h2>
          
          <div id="sidebar">
          <ul>
            <li><a href="addnewbook.php"><b>Add New Book</b></a></li>
            <li><a href="allBooksInfo.php"><b>All Book Information</b></a></li>
            <li><a href="viewStudentsList.php"><b>View Students List</b></a></li>
            <li><a href="viewTeachersList.php"><b>View Teachers List</b></a></li>
            <li><a href="studentLibraryAcc.php"><b>Create Student Library Account</b></a></li>
            <li><a href="viewAllStudentsLibProfile.php"><b>View Student Library Account</b></a></li>
            <li><a href="issueNewBook.php"><b>Add Issue Book</b></a></li>
            <li><a href="issuedBookHistory.php"><b>Issue Book History</b></a></li>
            
          </ul>
          </div>
        </td>
        <td id="pagetitle"><h2><?php echo $title; ?></h2>
        <div id="maincontent">
          <h2>Welcome to Library</h2>
          <p style="color: black;">A library is fundamentally an organized set of resources, which include human services as well as the entire spectrum of media (e.g., text, video, hypermedia). Libraries have physical components such as space, equipment, and storage media; intellectual components such as collection policies that determine what materials will be included and organizational schemes that determine how the collection is accessed; and people who manage the physical and intellectual components and interact with users to solve information problems. </p>
          </div>
          
        </td>
      </tr>
      </body>
   </html>
<?php include('footer.php'); ?>   

