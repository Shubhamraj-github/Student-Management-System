<?php $title= "Reset Password";
include('header.php');
   ?> 

    <table border="1" cellspacing="0" width="100%" >
      <tr>
        <td colspan="2">
          <table width="100%">
            <tr>
              <td><img height="50px" weight="50px" src="../Resources/logo.png" alt=""></td>
              <td align = "center"><h1>School Management System</h1></td>
              <td align = "right">
                <a href="../Controller/logout.php"><b>Logout</b></a>
              </td>
            </tr>
          </table>
        </td>
      </tr>
 
      <tr id="navigation">
        <td width="350px">
          <h2 align="center"><a href="viewLibrarianProfile.php">My Profile</a></h2></h2>
          <hr>
          <div id="sidebar">
          <ul>
            <li><a href="addnewbook.php"><b>Add New Book</b></a></li>
            <li><a href="allBooksInfo.php"><b>All Book Information</b></a></li>
            <li><a href="viewStudentsList.php"><b>View Students List</b></a></li>
            <li><a href="viewTeachersList.php"><b>View Teachers List</b></a></li>
            <li><a href="studentLibraryAcc.php"><b>Create Student Library Account</b></a></li>
            <li><a href="viewAllStudentsLibProfile.php"><b>View Student Library Account</b></a></li>
            <li><a href="issueNewBook.php"><b>Add Issue Book</b></a></li>
            <li><a href="issuedBookHistory.php"><b>Issue Book History</b></a></li>
            
          </ul>
          </div>
        </td>
        <td id="main content"><h2 align="center" ><?php echo $title; ?></h2><hr>
        <div id="chngpass">
        <form action="../Controller/changeLibrarianPassCheck.php" method="POST">
          <table align="center">
          <tr>
            <td>Current Password:</td>
            <td><input type="password" name="password" value="" placeholder="Enter Current Password"></td>
          </tr>
          <tr>
            <td>New Password:</td>
            <td><input type="password" name="newpassword" value="" placeholder="Enter New Password"></td>
          </tr>
          <tr>
            <td>Retype New Password:</td>
            <td><input type="password" name="repassword" value="" placeholder="Re-Enter New Password"></td>
          </tr>
          <tr>
            <td></td>
            <td><input type="submit" name="changepassword" value="Change Password" id=""></td>
          </tr>
         </table>
         </form>
         </div>
        </td>
      </tr>

<?php include('footer.php'); ?>   