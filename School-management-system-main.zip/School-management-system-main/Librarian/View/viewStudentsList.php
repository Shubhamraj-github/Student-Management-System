<?php 
$title= "View Student List";
include('header.php');
include_once('../Model/usersmodel.php');
$studentsinfo = getAllstudentsInfo();
?>
<<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
  <style type="text/css">
    input[type=button]{
  background-color: #22A7F0;
  width: auto;
  color: black;
  padding: 5px 10px;
  cursor: pointer;
}
input[type=button]:hover{
  opacity: 0.8;
}
  </style>
</head>
<body>



    <table border="1" cellspacing="0" width="100%" >
      <tr>
        <td colspan="2">
          <table width="100%">
            <tr>
              <td><img height="50px" weight="50px" src="../Resources/logo.png" alt=""></td>
              <td align = "center"><h1>School Management System</h1></td>
              <td align = "right">
                <a href="../Controller/logout.php"><b>Logout</b></a>
              </td>
            </tr>
          </table>
        </td>
      </tr>
 
      <tr id="navigation">
        <td width="350px">
        <h2 align="center"><a href="viewLibrarianProfile.php">My Profile</a></h2></h2>
          <h3 align="center"><a href="dashboard.php">Go to Dashboard</a></h3></br>
          <div id="sidebar">
          <ul>
            <li><a href="addnewbook.php"><b>Add New Book</b></a></li>
            <li><a href="allBooksInfo.php"><b>All Book Information</b></a></li>
            <li><a href="viewStudentsList.php"><b>View Students List</b></a></li>
            <li><a href="viewTeachersList.php"><b>View Teachers List</b></a></li>
            <li><a href="studentLibraryAcc.php"><b>Create Student Library Account</b></a></li>
            <li><a href="viewAllStudentsLibProfile.php"><b>View Student Library Account</b></a></li>
            <li><a href="issueNewBook.php"><b>Add Issue Book</b></a></li>
            <li><a href="issuedBookHistory.php"><b>Issue Book History</b></a></li>
            
          </ul>
          </div>
        </td>
        <td id="main content"><h2 align="center" ><?php echo $title; ?></h2><hr>
                    
        <script type="text/javascript" src="../js/searchStudentlist.js"></script>

<input type="text" name="name" id="name" placeholder="Enter Name" onkeyup="ajax()" />
	<input type="button" name="" value="Search">
    <br>
    <div id="viewstudentlist" class="">
    <div id="notice" >
    <table border="1">
    <tr align="center">
            <th>Name</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>Gender</th>
            <th>DOB</th>
            <th>Class</th>
            <th>Section</th>
            <th>Roll</th>
            <th>Present Address</th>
        </tr>
        <?php  for($i=0; $i < count($studentsinfo); $i++){ ?>
         <tr align="center">
             <td><?php echo $studentsinfo[$i]['name'] ?></td>
             <td><?php echo $studentsinfo[$i]['email'] ?></td>
             <td><?php echo $studentsinfo[$i]['mobile'] ?></td>
             <td><?php echo $studentsinfo[$i]['gender'] ?></td>
             <td><?php echo $studentsinfo[$i]['dob'] ?></td>
             <td><?php echo $studentsinfo[$i]['class'] ?></td>
             <td><?php echo $studentsinfo[$i]['section'] ?></td>
             <td><?php echo $studentsinfo[$i]['id'] ?></td>
             <td><?php echo $studentsinfo[$i]['p_address'] ?></td>
         </tr><?php  } ?></div>
             </table>
             </div>
        </div>    

      <?php include('footer.php'); ?>   
 </body>
</html>