-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2022 at 07:15 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` varchar(20) NOT NULL,
  `name` varchar(70) NOT NULL,
  `email` varchar(70) NOT NULL,
  `password` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
('9307', 'SHUBHAM ', 'srshubhamraj98841@gmail.com', 'Youwecan@12');

-- --------------------------------------------------------

--
-- Table structure for table `book_info`
--

CREATE TABLE `book_info` (
  `sl` int(11) NOT NULL,
  `isbn` varchar(30) NOT NULL,
  `title` varchar(70) NOT NULL,
  `author` varchar(70) NOT NULL,
  `edition` varchar(70) NOT NULL,
  `categories` varchar(100) NOT NULL,
  `bookfile` varchar(50) NOT NULL,
  `bookcopy` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book_info`
--

INSERT INTO `book_info` (`sl`, `isbn`, `title`, `author`, `edition`, `categories`, `bookfile`, `bookcopy`) VALUES
(17, '1234567892', 'let us java programming', 'Shubham', '1995', 'thriller', 'VIT PAYMENT REF NO.jpeg', '3'),
(18, '9874561231', 'Who is there?', 'Issac Newton', '1998', 'mystery', 'BOOK.jpeg', '3');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(3) NOT NULL,
  `course_name` varchar(20) NOT NULL,
  `class` varchar(10) NOT NULL,
  `description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `course_name`, `class`, `description`) VALUES
(8, 'Physics', 'Ten', 'physics '),
(9, 'MATHS', 'Six', 'Maths'),
(10, 'Chemistry', 'Ten', 'Chemistry\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `edit_student`
--

CREATE TABLE `edit_student` (
  `id` varchar(4) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `p_address` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `edit_student`
--

INSERT INTO `edit_student` (`id`, `name`, `email`, `mobile`, `gender`, `dob`, `p_address`) VALUES
('1002', 'Shubham', 'bhavesh@gmail.com', '98745632100', 'male', '1998-05-15', 'DUMARI'),
('2222', 'BHAVESH RANJAN', 'bhavesh@gmail.com', '98745632100', 'male', '1998-05-15', 'West Bengal');

-- --------------------------------------------------------

--
-- Table structure for table `issuedbookdetails`
--

CREATE TABLE `issuedbookdetails` (
  `serialno` int(3) NOT NULL,
  `isbn` int(4) NOT NULL,
  `title` varchar(50) NOT NULL,
  `id` int(4) NOT NULL,
  `issuesdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `returndate` date NOT NULL,
  `returnstatus` int(2) NOT NULL,
  `fine` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issuedbookdetails`
--

INSERT INTO `issuedbookdetails` (`serialno`, `isbn`, `title`, `id`, `issuesdate`, `returndate`, `returnstatus`, `fine`) VALUES
(19, 1234567891, 'let us c programming', 1002, '2022-07-17 17:31:42', '0000-00-00', 0, 75),
(20, 1234567891, 'let us c programming', 1002, '2022-07-17 17:31:42', '0000-00-00', 0, 75),
(21, 1234567891, 'let us c programming', 1002, '2022-07-17 17:31:42', '0000-00-00', 0, 75),
(22, 1234567891, 'let us c programming', 1002, '2022-07-17 17:31:42', '0000-00-00', 0, 75),
(23, 1234567891, 'let us c programming', 1005, '2022-07-17 16:11:11', '2022-07-17', 0, 75),
(24, 1234567892, 'Who is there?', 1111, '2022-07-10 14:40:08', '2022-07-11', 1, 15),
(25, 2147483647, 'let us c programming', 1002, '2022-07-17 17:31:42', '0000-00-00', 0, 75);

-- --------------------------------------------------------

--
-- Table structure for table `leave_request`
--

CREATE TABLE `leave_request` (
  `sl` int(3) NOT NULL,
  `id` varchar(4) NOT NULL,
  `name` varchar(50) NOT NULL,
  `leave_from` date NOT NULL,
  `leave_to` date NOT NULL,
  `action` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `leave_request`
--

INSERT INTO `leave_request` (`sl`, `id`, `name`, `leave_from`, `leave_to`, `action`) VALUES
(8, '1002', 'Rahul', '2022-07-07', '2022-07-22', 'Accepted'),
(9, '1111', 'AMAN KUMAR', '2022-07-11', '2022-07-16', 'Accepted'),
(10, '1002', 'Aman', '2022-07-18', '2022-07-21', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `librarian`
--

CREATE TABLE `librarian` (
  `slno` int(11) NOT NULL,
  `id` varchar(4) NOT NULL,
  `name` varchar(70) NOT NULL,
  `email` varchar(70) NOT NULL,
  `mobile` varchar(70) NOT NULL,
  `gender` varchar(70) NOT NULL,
  `dob` varchar(10) NOT NULL,
  `password` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `librarian`
--

INSERT INTO `librarian` (`slno`, `id`, `name`, `email`, `mobile`, `gender`, `dob`, `password`) VALUES
(44, '1111', 'SHUBHAM RAJ', 'shubham@gmail.com', '07979026640', 'male', '2001-01-20', 'Youwecan@12'),
(45, '2222', 'BHAVESH ', 'bhavesh@gmail.com', '09708314884', 'male', '1998-11-03', 'Youwecan@12'),
(47, '7002', 'Deepak', 'deepak@gmail.com', '09708314884', 'male', '1998-11-03', '123456789');

-- --------------------------------------------------------

--
-- Table structure for table `librariannotice`
--

CREATE TABLE `librariannotice` (
  `noticeid` int(4) NOT NULL,
  `noticetitle` varchar(40) NOT NULL,
  `noticedetails` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `librariannotice`
--

INSERT INTO `librariannotice` (`noticeid`, `noticetitle`, `noticedetails`) VALUES
(4, 'learn webdevelopment', 'learn webdevelopmentlearn webdevelopmentlearn webdevelopmentlearn webdevelopment');

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `id` int(11) NOT NULL,
  `notes` varchar(50) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`id`, `notes`, `time`) VALUES
(7, 'VIT PAYMENT REF NO.jpeg', '2022-07-09 12:05:30');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `id` int(3) NOT NULL,
  `notice` varchar(500) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`id`, `notice`, `time`) VALUES
(10, 'School is closed', '2022-07-09 11:04:52'),
(11, 'School is closed today', '2022-07-18 05:45:29');

-- --------------------------------------------------------

--
-- Table structure for table `requestbook`
--

CREATE TABLE `requestbook` (
  `sl` int(11) NOT NULL,
  `isbn` varchar(70) NOT NULL,
  `title` varchar(70) NOT NULL,
  `author` varchar(70) NOT NULL,
  `edition` varchar(70) NOT NULL,
  `id` int(4) NOT NULL,
  `requestdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `routine`
--

CREATE TABLE `routine` (
  `day` varchar(50) NOT NULL,
  `10:00-11:00` varchar(50) NOT NULL,
  `11:00-12:00` varchar(50) NOT NULL,
  `12:00-01:00` varchar(50) NOT NULL,
  `01:00-02:00` varchar(50) NOT NULL,
  `02:00-03:00` varchar(50) NOT NULL,
  `03:00-04:00` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `school_notice`
--

CREATE TABLE `school_notice` (
  `id` int(3) NOT NULL,
  `notice` varchar(500) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `school_notice`
--

INSERT INTO `school_notice` (`id`, `notice`, `time`) VALUES
(6, 'School is closed till further notice.', '2022-07-10 14:12:06');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` varchar(20) NOT NULL,
  `name` varchar(70) NOT NULL,
  `email` varchar(70) NOT NULL,
  `mobile` varchar(70) NOT NULL,
  `gender` varchar(70) NOT NULL,
  `dob` varchar(10) NOT NULL,
  `class` varchar(10) NOT NULL,
  `section` varchar(10) NOT NULL,
  `roll` varchar(70) NOT NULL,
  `p_address` varchar(70) NOT NULL,
  `password` varchar(70) NOT NULL,
  `marks` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `email`, `mobile`, `gender`, `dob`, `class`, `section`, `roll`, `p_address`, `password`, `marks`) VALUES
('1002', 'Aman', 'aman@gmail.com', '07979026640', 'male', '1998-11-03', 'Eight', 'A', '30', 'Kolkata', 'Youwecan@12', '98'),
('1111', 'Ritesh', 'aman@gmail.com', '07979026640', 'male', '1998-11-03', 'Six', 'A', '01', 'kolkata', 'Youwecan@12', '80'),
('2222', 'Monu', 'monu@gmail.com', '09708314884', 'male', '1998-11-03', 'Seven', 'B', '02', 'Delhi', 'Youwecan@12', '95'),
('3333', 'Golu', 'golu@gmail.com', '09708314884', 'male', '1999-07-15', 'Eight', 'A', '21', 'Boring Road', 'Youwecan@12', '98');

-- --------------------------------------------------------

--
-- Table structure for table `studentslibraryaccount`
--

CREATE TABLE `studentslibraryaccount` (
  `serialno` int(3) NOT NULL,
  `id` int(4) NOT NULL,
  `name` varchar(20) NOT NULL,
  `mail` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentslibraryaccount`
--

INSERT INTO `studentslibraryaccount` (`serialno`, `id`, `name`, `mail`, `gender`) VALUES
(68, 1002, 'Rahul', 'rahul44@gmail.com', 'male'),
(69, 1005, 'Ashish', 'ashish@gmail.com', 'male'),
(70, 1111, 'AMAN KUMAR', 'aman@gmail.com', 'male'),
(71, 2222, 'RITESH', 'ritesh@gmail.com', 'male');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id` varchar(20) NOT NULL,
  `name` varchar(70) NOT NULL,
  `email` varchar(70) NOT NULL,
  `mobile` varchar(70) NOT NULL,
  `gender` varchar(70) NOT NULL,
  `dob` date NOT NULL,
  `subject` varchar(30) NOT NULL,
  `password` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`id`, `name`, `email`, `mobile`, `gender`, `dob`, `subject`, `password`) VALUES
('1001', 'RAHUL', 'rahul@gmail.com', '12345678900', 'male', '1998-11-03', 'Physical education and health', 'Youwecan@12'),
('1111', 'SHUBHAM RAJ', 'shubham@gmail.com', '07979026640', 'male', '1998-11-03', 'Physics', 'Youwecan@12'),
('2222', 'BHAVESH', 'bhavesh@gmail.com', '07979026640', 'male', '1999-03-20', 'Math', 'Youwecan@12'),
('3333', 'ASHISH ', 'ashish@gmail.com', '09708314884', 'male', '2001-04-16', 'English', 'Youwecan@12'),
('4444', 'RAJVEER', 'rajveer@gmail.com', '09708314884', 'male', '1998-12-05', 'Physics', 'Youwecan@12'),
('8888', 'Ravi Soni', 'ravi@gmail.com', '07979026640', 'male', '1995-01-20', 'Physics', 'Youwecan@12');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_notes`
--

CREATE TABLE `teacher_notes` (
  `id` int(11) NOT NULL,
  `notes` varchar(20) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher_notes`
--

INSERT INTO `teacher_notes` (`id`, `notes`, `time`) VALUES
(6, 'WhatsApp Image 2022-', '2022-07-09 11:44:46');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_info`
--
ALTER TABLE `book_info`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `edit_student`
--
ALTER TABLE `edit_student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `issuedbookdetails`
--
ALTER TABLE `issuedbookdetails`
  ADD PRIMARY KEY (`serialno`);

--
-- Indexes for table `leave_request`
--
ALTER TABLE `leave_request`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `librarian`
--
ALTER TABLE `librarian`
  ADD PRIMARY KEY (`slno`);

--
-- Indexes for table `librariannotice`
--
ALTER TABLE `librariannotice`
  ADD PRIMARY KEY (`noticeid`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requestbook`
--
ALTER TABLE `requestbook`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `routine`
--
ALTER TABLE `routine`
  ADD UNIQUE KEY `day` (`day`);

--
-- Indexes for table `school_notice`
--
ALTER TABLE `school_notice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `studentslibraryaccount`
--
ALTER TABLE `studentslibraryaccount`
  ADD PRIMARY KEY (`serialno`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher_notes`
--
ALTER TABLE `teacher_notes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book_info`
--
ALTER TABLE `book_info`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `issuedbookdetails`
--
ALTER TABLE `issuedbookdetails`
  MODIFY `serialno` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `leave_request`
--
ALTER TABLE `leave_request`
  MODIFY `sl` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `librarian`
--
ALTER TABLE `librarian`
  MODIFY `slno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `librariannotice`
--
ALTER TABLE `librariannotice`
  MODIFY `noticeid` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `requestbook`
--
ALTER TABLE `requestbook`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `school_notice`
--
ALTER TABLE `school_notice`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `studentslibraryaccount`
--
ALTER TABLE `studentslibraryaccount`
  MODIFY `serialno` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `teacher_notes`
--
ALTER TABLE `teacher_notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
