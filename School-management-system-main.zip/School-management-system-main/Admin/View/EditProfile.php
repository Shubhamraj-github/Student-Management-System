<?php
	$title= "Edit Profile";
	$js = "../Script/EditProfileVal.js";
	include('header.php');
	include_once('../model/adminModel.php');
	$viemyinfo = getUserbyid($_COOKIE['id']);
?>
								<div id="sidebar" class="">
                <ul>
                  <li><a href="Dashboard.php"><b>Dashbord</b></a></li>
                  <li><a href="viewProfile.php"><b>View Profile</b></a></li>
                  <li><a href="EditProfile.php"><b>Edit Profile</b></a></li>
                  <li><a href="ChangePassword.php"><b>Change Password</b></a></li>
                  <li><a href="../Controller/logout.php"><b>Logout</b></a></li>
                </ul>
							</div >
              </td>

              <td>
								<form class="" id="inform" action="../Controller/editadminCheck.php" onsubmit="return validation()" method="post">
								<table>
									<tr>
										<td colspan="2">
											<center>
											<div id="error_messege">
											</div>
										</center>
									</tr>
									<tr>
										<td><b>ID</b></td>
										<td><b>:</b> <input type="text" id="id" name="id" disabled value="<?php echo $viemyinfo['id']; ?>"></td>
									</tr>
									<tr>
										<td><b>Name</b></td>
										<td><b>:</b> <input type="text" id="name" name="name" value="<?php echo $viemyinfo['name']; ?>"></td>
									</tr>
									<tr>
										<td><b>Email</b></td>
										<td><b>:</b> <input type="email" id="email" name="email" value="<?php echo $viemyinfo['email']; ?>"></td>
									</tr>

								</table>
								<hr>
									<input type="submit" name="submit" value="Submit">
								</form>


              </td>
            </tr>
          </table>
        </td>
      </tr>




<?php include('footer.php'); ?>
