<?php
	$title= "view notice";
	include('header.php');
  include_once('../model/noticeModel.php');
  $UsersList = allUserList();
?>
<div id="sidebar" class="">
                <ul>
                  <li><a href="postNotice.php"><b>Notice<b></a></li>
									<li><a href="viewNotice.php"><b>View Notice</b></a></li>
                </ul>
							</div>
              </td>
              <td>
                 <center><h2>All Notice</h2></center>
                <?php
								echo "<table border = 1 width='100%' cellspacing = 0  >
								<tr align = 'center'>
                    <td><b>ID</b></td>
								    <td><b>Notice</b></td>
								    <td><b>Time</b></td>
										<td><b>Action</b></td>

								</tr>";
								for($i = 0; $i<count($UsersList); $i++){
								    echo "<tr align = 'center'>
								    <td>{$UsersList[$i]['id']}</td>
								    <td>{$UsersList[$i]['notice']}</td>
								    <td>{$UsersList[$i]['time']}</td>
								    <td> <a href='editNotice.php?id={$UsersList[$i]['id']}'> Update </a> | <a href='deleteNotice.php?id={$UsersList[$i]['id']}'> Delete </a>  </td>
								</tr>";
								}
								echo "</table>";
								?>
              </td>
            </tr>
          </table>
        </td>
      </tr>
<?php include('footer.php'); ?>
