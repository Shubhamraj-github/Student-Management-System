<?php
	$title= "View Student";
	$js = "../script/StudentSearch.js";
	include('header.php');
	include_once('../model/studentModel.php');
	$UsersList = allUserList();
?>
<div id="sidebar" class="">
                <ul>
                  <li><a href="addStudent.php"><b>Add Student</b></a></li>
                  <li><a href="viewStudent.php"><b>View Student</b></a></li>
                    <li><a href="editrequestlist.php"><b>Edit Request</b></a></li>
                  <li><a href="dashboard.php"><b>Dashbord</b></a></li>
                  <li><a href="../Controller/logout.php"><b>Logout</b></a></li>

                </ul>
							</div>
              </td>

              <td>
                <center><h2>Student list</h2>
									<input type="text" name="name" id="name" placeholder="Enter Id No" onkeyup="ajax()" />
									<input type="button" name="" value="Search">
								</center>
								<div id="myh1" class="">
									<br>
								<?php
								echo "<table border = 1 width='100%' cellspacing = 0  >
								<tr align = 'center'>
										<td><b>Id</b></td>
										<td><b>Name</b></td>
										<td><b>Email</b></td>
										<td><b>Mobile</b></td>
										<td><b>Gender</b></td>
										<td><b>DOB</b></td>
										<td><b>Present Address</b></td>
										<td><b>Class</b></td>
										<td><b>Section</b></td>
										<td><b>Roll</b></td>
										<td><b>Action</b></td>
								</tr>";
								for($i = 0; $i<count($UsersList); $i++){
										echo "<tr align = 'center'>
										<td>{$UsersList[$i]['id']}</td>
										<td>{$UsersList[$i]['name']}</td>
										<td>{$UsersList[$i]['email']}</td>
										<td>{$UsersList[$i]['mobile']}</td>
										<td>{$UsersList[$i]['gender']}</td>
										<td>{$UsersList[$i]['dob']}</td>
										<td>{$UsersList[$i]['p_address']}</td>
										<td>{$UsersList[$i]['class']}</td>
										<td>{$UsersList[$i]['section']}</td>
										<td>{$UsersList[$i]['roll']}</td>
										<td> <a href='editStudent.php?id={$UsersList[$i]['id']}'><b> Edit</b> </a> | <a href='deleteStudent.php?id={$UsersList[$i]['id']}'><b> Delete</b> </a>  </td>
								</tr>";
								}
								echo "</table>";
								?>
								</div>

              </td>
            </tr>
          </table>
        </td>
      </tr>




      <?php include('footer.php'); ?>
