<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>LOGIN</title>
    <link rel="stylesheet" href="../Style/adminlogin.css">
    <style media="screen">
    #error_messege{
      color: White;
      font-weight: bold;
      margin-bottom: 20px;
      padding: 0px;
      background: #de0404;
      text-align: center;
      font-size: 18px;
      transition: all 0.5s ease;
    }

    h1{
  color: black;
    text-shadow: 5px 5px 8px  purple;
    font-size:300%;
  }
  img {
  border: 5px solid black;
}



legend {
  background-color: red;
  color: white;
  padding: 5px 10px;
}
  a {
  background-color: blueviolet;
  color: white ;
  padding: 1em 1.5em;
  text-decoration: none;
  text-transform: uppercase;
}
body {
 background-image: url("../Resources/background.png");
 background-repeat: no-repeat;
 background-size: cover;
}
input[type=text] {
  border: 2px solid red;
  border-radius: 4px;
}
input[type=password] {
  border: 2px solid red;
  border-radius: 4px;
}
table
{
border-color: transparent;
}

    </style>

    <script src="../Script/adminloginVal.js"></script>
  </head>
  <body>
    <table border="1" cellspacing="0" width="100%" >
      <tr>
        <td>
          <table width="100%">
            <tr>
              <td><img height="50px" weight="50px" src="../Resources/logo.png" alt=""></td>
              <td align = "center"><h1>School Management System</h1></td>
              <td align = "right">
                <a href="../../Home/index.html">Back</a>
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td>
          <div id="formtable" class="">


          <table  align="center" >
            <tr>
              <td>
                <form class="" id="inform" action="../Controller/logCheck.php" onsubmit="return validation()" method="post">
                  <fieldset>
                    <legend>LOGIN</legend>
                    <table>
                      <tr>
                        <td colspan="2">
                          <center>
                          <div id="error_messege">
                          </div>
                        </center>
                      </tr>
                      <tr>
                        <td><b>ID</b></td>
                        <td>: <input type="text" id="id" name="id" value="" placeholder="9307"></td>
                      </tr>
                      <tr>
                        <td><b>Password</b></td>
                        <td>: <input type="password" id="password" name="password" value=""placeholder=" Youwecan@12"></td>
                      </tr>
                    </table>
                    <br>
                    <input type="submit" id="submit" name="submit" value="LOGIN">
                    <br>
                  </fieldset>
                </form>
            </td>

          </tr>
          </table>
          </div>
        </td>
      </tr>

      <tr>
        <td align="center" ><b>Copyright Ⓒ 2022</b></td>
      </tr>

    </table>

  </body>
</html>
