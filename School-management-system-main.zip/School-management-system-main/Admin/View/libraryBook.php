<?php
	$title= "Library Book";
	$js = "../script/BookSearch.js";
	include('header.php');
	include_once('../model/bookModel.php');
	$UsersList = allUserList();
?>
<div id="sidebar" class="">
                <ul>
                  <li><a href="libraryBook.php"><b>Library Book list</b></a></li>
                </ul>
							</div>
              </td>
              <td>
                <center><h2  >Library Book list</h2>
								<input type="text" name="name" id="name" placeholder="Enter Title" onkeyup="ajax()" />
								<input type="button" name="" value="Search">
								
								</center>
								<br>
								<div id="myh1" class="">
									<?php
									echo "<table  border = 1 width='100%' cellspacing = 0  >
									<tr align = 'center'>
											<td><b>ISBN</b></td>
											<td><b>Title</b></td>
											<td><b>Author</b></td>
											<td><b>Edition</b></td>
											<td><b>Categories</b></td>
											<td><b>Book Copy</b></td>
									</tr>";
									for($i = 0; $i<count($UsersList); $i++){
											echo "<tr align = 'center'>
											<td>{$UsersList[$i]['isbn']}</td>
											<td>{$UsersList[$i]['title']}</td>
											<td>{$UsersList[$i]['author']}</td>
											<td>{$UsersList[$i]['edition']}</td>
											<td>{$UsersList[$i]['categories']}</td>
											<td>{$UsersList[$i]['bookcopy']}</td>
									</tr>";
									}
									echo "</table>";
									?>
								</div>

							</td>
            </tr>
          </table>
        </td>
      </tr>

<?php include('footer.php'); ?>
