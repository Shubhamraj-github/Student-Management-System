<?php
	$title= "view profile";
	include('header.php');
	include_once('../model/adminModel.php');
	$viemyinfo = getUserbyid($_COOKIE['id']);

?>
								<div id="sidebar" class="">
                <ul>
                  <li><a href="Dashboard.php"><b>Dashbord</b></a></li>
                  <li><a href="viewProfile.php"><b>View Profile</b></a></li>
                  <li><a href="EditProfile.php"><b>Edit Profile</b></a></li>
                  <li><a href="ChangePassword.php"><b>Change Password</b></a></li>
                  <li><a href="../Controller/logout.php"><b>Logout</b></a></li>
                </ul>
							</div>
              </td>

              <td>
								<fieldset>
                  <legend><b>View Profile Information</b></legend>
										<table>
											<tr>
												<td><b>ID</b></td>
												<td><b>:</b> <?php echo $viemyinfo['id']; ?></td>
											</tr>
											<tr>
												<td><b>Name</b></td>
												<td><b>:</b> <?php echo $viemyinfo['name']; ?></td>
											</tr>
											<tr>
												<td><b>Email</b></td>
												<td><b>:</b> <?php echo $viemyinfo['email']; ?></td>
											</tr>
										</table>
										<hr>
										<br>
										<a href="EditProfile.php"><b>Edit Profile</b></a>


		              </td>
		            </tr>
		          </table>
						</fieldset>
        </td>
      </tr>




      <?php include('footer.php'); ?>
