<?php
	session_start();
	if(!isset($_COOKIE['flag']))
	{
    header('location: adminlogin.php');
  }

?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title><?=$title?></title>
		<link rel="stylesheet" href="../Style/sidebar.css">
		<style media="screen">
      #error_messege{
				color: White;
	      font-weight: bold;
	      margin-bottom: 20px;
	      padding: 0px;
	      background: #de0404;
	      text-align: center;
	      font-size: 18px;
	      transition: all 0.5s ease;
      }
      body {
 background-image: url("../Resources/background1.jpg");
 background-repeat: no-repeat;
 background-size: cover;
}
      h1{
  color: black;
    text-shadow: 5px 5px 8px  purple;
    font-size:300%;
  }
  img {
  border: 5px solid black;
}

table{
  border-style: dotted;
  border-color: transparent;
}
legend {
  background-color: red;
  color: white;
  padding: 5px 10px;
}
fieldset{
border-color: black;
}
 img:hover {
  
  animation: shake 0.5s;

  
  animation-iteration-count: infinite;
}

@keyframes shake {
  0% { transform: translate(1px, 1px) rotate(0deg); }
  10% { transform: translate(-1px, -2px) rotate(-1deg); }
  20% { transform: translate(-3px, 0px) rotate(1deg); }
  30% { transform: translate(3px, 2px) rotate(0deg); }
  40% { transform: translate(1px, -1px) rotate(1deg); }
  50% { transform: translate(-1px, 2px) rotate(-1deg); }
  60% { transform: translate(-3px, 1px) rotate(0deg); }
  70% { transform: translate(3px, 1px) rotate(-1deg); }
  80% { transform: translate(-1px, -1px) rotate(1deg); }
  90% { transform: translate(1px, 2px) rotate(0deg); }
  100% { transform: translate(1px, -2px) rotate(-1deg); }
}

			</style>
		<script src="<?=$js?>"></script>

  </head>
  <body>
  
    <table border="1" cellspacing="0" width="100%">
      <tr>
        <td>
          <table width="100%">
            <tr id="header">
              <td><a href="dashboard.php"><img height="50px" weight="50px" src="../Resources/logo.png" alt=""></a></td>
              <td align = "center"><h1>School Management System</h1></td>
              <td align = "right">
                <a href="dashboard.php">Back</a> |
                <a href="../Controller/logout.php"><span class="tab">Logout</a>

              </td>
            </tr>
          </table>
        </td>
      </tr>

      <tr>
        <td>
          <table width="100%" cellspacing="0" border="1">
            <tr id="navigation">
              <td width="250px">
                <center>
                  <h3>Login As</h3>
                  <h2>
										<a href="viewProfile.php"><?php echo $_COOKIE['name'];?></a>
									</h2>
                  <p>(Admin)</p>
                </center>
                <hr>
