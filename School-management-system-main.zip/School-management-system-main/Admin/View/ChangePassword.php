<?php
	$title= "Change Password";
	$js = "../Script/ChangPassVal.js";
	include('header.php');

?>
<div id="sidebar" class="">
                <ul>
                  <li><a href="Dashboard.php"><b>Dashbord</b></a></li>
                  <li><a href="viewProfile.php"><b>View Profile</b></a></li>
                  <li><a href="EditProfile.php"><b>Edit Profile</b></a></li>
                  <li><a href="ChangePassword.php"><b>Change Password</b></a></li>
                  <li><a href="../Controller/logout.php"><b>Logout</b></a></li>
                </ul>
              </td>
							

							</div>

              <td>
								<form class="" id="inform" action="../controller/chaPassCheck.php" onsubmit="return validation()" method="post">
			            <fieldset>
			              <legend><b>CHANGE PASSWORD</b></legend>
			              <table>
											<tr>
												<td colspan="2">
													<center>
													<div id="error_messege">
													</div>
												</center>
											</tr>
			                <tr>
			                  <td><b>Current Password:</b></td>
			                  <td><input type="password" id="cpas" name="cpas" value="" placeholder="Enter Current Password"></td>
			                </tr>
			                <tr>
			                  <td><b>New Password:</b></td>
			                  <td><input type="password" id="npass" name="npass" value="" placeholder="Enter New Password"></td>
			                </tr>
			                <tr>
			                  <td><b>Retype New Password:</b></td>
			                  <td><input type="password" id="rnpass" name="rnpass" value="" placeholder="Enter New Password"></td>
			                </tr>
			              </table>
			              <hr>
			              <input type="submit" name="Change" value="Change"> <br>
			            </fieldset>
			          </form>
              </td>
            </tr>
          </table>
        </td>
      </tr>


  <?php include('footer.php'); ?>
