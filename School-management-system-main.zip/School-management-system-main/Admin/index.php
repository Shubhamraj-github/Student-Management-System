<?php

	header('location: view/adminlogin.php');

?>
